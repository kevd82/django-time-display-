from django.apps import AppConfig


class ApptdConfig(AppConfig):
    name = 'APPtd'
